<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
    <link rel="stylesheet" href="./css/homepage.css">
    <link rel="stylesheet" href="./css/font-awesome-4.7.0/css/font-awesome.css">
    <title>Homepage</title>
</head>
<body>
    
    <div class="container">
        <div class="title">
            <span class="heading">Student Result Management System</span>
        </div>
        
        <div class="nav">
            <ul>
                <li>
                    <a href="index.html">Home</a>
                </li>
                <li>
                    <a href="login.php">Admin Login</a>
                </li>
                <li class="dropdown" onclick="toggleDisplay('1')">
                    <a href="#" class="dropbtn">Faculties &nbsp
                        <span class="fa fa-angle-down"></span>
                    </a>
                    <div class="dropdown-content" id="1">
                        <a href="">Arts</a>
                        <a href="">Science</a>
                        <a href="">Commerce</a>
                        <a href="">Technology</a>
                        <a href="">Sports</a>
                        <a href="">Others</a>
                    </div>
                </li>
                <li class="dropdown" onclick="toggleDisplay('2')">
                    <a href="#" class="dropbtn">Student &nbsp
                        <span class="fa fa-angle-down"></span>
                    </a>
                    <div class="dropdown-content" id="2">
                        <a href="">Admissions</a>
                        <a href="">Scholarship</a>
                        <a href="">Examination</a>
                        <a href="./login.php">Results</a>
                        <a href="">Manage Results</a>
                    </div>
                </li>
            </ul>
        </div>
    
        <div class="slider">
            <img src="images/examp.jpg" class="slider-image" alt="img">
        </div>
    
        <div class="main">
            <span>About This Project</span>
			
			<p>The main objective of the project is to provide the examination result to the student in a simple way.
This project is useful for students and institutions for getting the results in simple manner.
By a result analyzer with subject status and marks is an application tool for displaying the results in secure way.</p>
           
        </div>


    </div>

</body>
</html>